search_text = 'classic sunglasses'
brand = 'Royal Robbins'
max_price = 200.00
color = 'Orange'