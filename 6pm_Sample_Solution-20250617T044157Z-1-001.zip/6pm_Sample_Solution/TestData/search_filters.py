search_data = "classic sunglasses"
brand_name = "RAEN Optics"
price_range = "$200.00 and Under"
color = "Orange"

